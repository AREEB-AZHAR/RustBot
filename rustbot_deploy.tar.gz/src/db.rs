use argon2::password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString};
use argon2::Argon2;
use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::path::Path;
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use subtle::ConstantTimeEq;

pub fn now_timestamp() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}

/// Generates a cryptographically secure random opaque identifier.
pub fn generate_secure_id(prefix: &str) -> String {
    let mut bytes = [0u8; 16];
    getrandom::getrandom(&mut bytes).expect("Fatal error: failed to acquire OS entropy");
    format!("{prefix}_{}", hex::encode(bytes))
}

/// Generates a cryptographically secure random token (32 bytes / 256 bits).
pub fn generate_secure_token() -> String {
    let mut bytes = [0u8; 32];
    getrandom::getrandom(&mut bytes).expect("Fatal error: failed to acquire OS entropy");
    hex::encode(bytes)
}

/// Hashes a token with SHA-256 and an optional session pepper.
pub fn digest_token(raw_token: &str, pepper: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(raw_token.as_bytes());
    if !pepper.is_empty() {
        hasher.update(b":");
        hasher.update(pepper.as_bytes());
    }
    hex::encode(hasher.finalize())
}

/// Compares two digests in constant time to prevent timing attacks.
pub fn constant_time_eq_str(a: &str, b: &str) -> bool {
    if a.len() != b.len() {
        return false;
    }
    a.as_bytes().ct_eq(b.as_bytes()).into()
}

/// Hash a password using Argon2id with cryptographically random salt.
pub fn hash_password(password: &str) -> Result<String, String> {
    if password.len() < 8 {
        return Err("Password must be at least 8 characters long.".to_string());
    }
    if password.len() > 256 {
        return Err("Password exceeds maximum allowed length.".to_string());
    }

    let mut salt_bytes = [0u8; 16];
    getrandom::getrandom(&mut salt_bytes).map_err(|e| format!("Entropy failure: {e}"))?;
    let salt = SaltString::encode_b64(&salt_bytes)
        .map_err(|e| format!("Failed to encode salt: {e}"))?;

    let argon2 = Argon2::default();
    let password_hash = argon2
        .hash_password(password.as_bytes(), &salt)
        .map_err(|e| format!("Password hashing failed: {e}"))?
        .to_string();

    Ok(password_hash)
}

/// Verifies a plain text password against an Argon2 hash.
pub fn verify_password(password: &str, password_hash: &str) -> bool {
    let parsed_hash = match PasswordHash::new(password_hash) {
        Ok(h) => h,
        Err(_) => return false,
    };
    Argon2::default()
        .verify_password(password.as_bytes(), &parsed_hash)
        .is_ok()
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct UserRecord {
    pub id: String,
    pub username: String,
    pub email: Option<String>,
    pub password_hash: String,
    pub role: String,
    pub is_verified: bool,
    pub created_at: i64,
    pub disabled_at: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SessionRecord {
    pub id: String,
    pub user_id: String,
    pub token_digest: String,
    pub csrf_token_digest: String,
    pub created_at: i64,
    pub last_seen_at: i64,
    pub expires_at: i64,
    pub revoked_at: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ConversationRecord {
    pub id: String,
    pub user_id: String,
    pub title: Option<String>,
    pub created_at: i64,
    pub updated_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct MessageRecord {
    pub id: String,
    pub conversation_id: String,
    pub role: String,
    pub content: String,
    pub status: Option<String>,
    pub created_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct MemoryRecord {
    pub id: i64,
    pub keywords: Vec<String>,
    pub response: String,
    pub match_mode: String,
    pub category: String,
    pub created_at: i64,
    pub updated_at: i64,
    pub owner_user_id: Option<String>,
    pub updated_by_user_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ImportStats {
    pub total_read: usize,
    pub inserted: usize,
    pub skipped: usize,
    pub rejected: usize,
}

#[derive(Clone)]
pub struct Database {
    conn: Arc<Mutex<Connection>>,
}

impl Database {
    /// Opens or creates SQLite database with foreign keys, WAL mode, and runs migrations.
    pub fn open(path: &Path) -> Result<Self, String> {
        let conn = Connection::open(path)
            .map_err(|e| format!("Failed to open SQLite database at {:?}: {e}", path))?;

        let db = Self {
            conn: Arc::new(Mutex::new(conn)),
        };
        db.init_pragmas()?;
        db.run_migrations()?;
        Ok(db)
    }

    /// Creates an in-memory database instance (primarily for automated tests).
    pub fn open_in_memory() -> Result<Self, String> {
        let conn = Connection::open_in_memory()
            .map_err(|e| format!("Failed to open in-memory SQLite database: {e}"))?;

        let db = Self {
            conn: Arc::new(Mutex::new(conn)),
        };
        db.init_pragmas()?;
        db.run_migrations()?;
        Ok(db)
    }

    fn init_pragmas(&self) -> Result<(), String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute_batch(
            "PRAGMA foreign_keys = ON;
             PRAGMA busy_timeout = 5000;
             PRAGMA synchronous = NORMAL;",
        )
        .map_err(|e| format!("Failed to set SQLite pragmas: {e}"))?;

        // WAL mode is applied if not in memory
        let _ = conn.execute_batch("PRAGMA journal_mode = WAL;");
        Ok(())
    }

    fn run_migrations(&self) -> Result<(), String> {
        let mut conn = self.conn.lock().map_err(|e| e.to_string())?;
        let tx = conn
            .transaction()
            .map_err(|e| format!("Failed to start migration transaction: {e}"))?;

        tx.execute_batch(
            "CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at INTEGER NOT NULL
            );",
        )
        .map_err(|e| format!("Failed to initialize schema_migrations table: {e}"))?;

        let migrations: &[(i64, &str, &str)] = &[
            (
                1,
                "001_initial_users",
                "CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL COLLATE NOCASE,
                    email TEXT UNIQUE COLLATE NOCASE,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('user', 'admin')),
                    is_verified INTEGER NOT NULL DEFAULT 1,
                    created_at INTEGER NOT NULL,
                    disabled_at INTEGER
                );
                CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
                CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);",
            ),
            (
                2,
                "002_sessions",
                "CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    token_digest TEXT UNIQUE NOT NULL,
                    csrf_token_digest TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    last_seen_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    revoked_at INTEGER
                );
                CREATE INDEX IF NOT EXISTS idx_sessions_token_digest ON sessions(token_digest);
                CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);",
            ),
            (
                3,
                "003_conversations_and_messages",
                "CREATE TABLE IF NOT EXISTS conversations (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    title TEXT,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    deleted_at INTEGER
                );
                CREATE INDEX IF NOT EXISTS idx_conversations_user_updated ON conversations(user_id, updated_at DESC);

                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
                    role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
                    content TEXT NOT NULL,
                    status TEXT,
                    created_at INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_messages_conversation_created ON messages(conversation_id, created_at ASC);",
            ),
            (
                4,
                "004_memories",
                "CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    keywords TEXT NOT NULL,
                    response TEXT NOT NULL,
                    match_mode TEXT NOT NULL DEFAULT 'phrase',
                    category TEXT NOT NULL DEFAULT 'general',
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    updated_by_user_id TEXT REFERENCES users(id)
                );
                CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category);",
            ),
            (
                5,
                "005_usage_limits",
                "CREATE TABLE IF NOT EXISTS ai_usage (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    occurred_at INTEGER NOT NULL,
                    model TEXT NOT NULL,
                    input_tokens INTEGER,
                    output_tokens INTEGER,
                    request_status TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_ai_usage_user_time ON ai_usage(user_id, occurred_at DESC);",
            ),
            (
                6,
                "006_memory_ownership",
                "ALTER TABLE memories ADD COLUMN owner_user_id TEXT REFERENCES users(id);
                UPDATE memories SET owner_user_id = updated_by_user_id WHERE owner_user_id IS NULL AND updated_by_user_id IS NOT NULL;
                CREATE INDEX IF NOT EXISTS idx_memories_owner ON memories(owner_user_id);",
            ),
        ];

        for (version, name, sql) in migrations {
            let already_applied: bool = tx
                .query_row(
                    "SELECT 1 FROM schema_migrations WHERE version = ?1",
                    params![version],
                    |_| Ok(true),
                )
                .optional()
                .map_err(|e| format!("Failed to check migration {version}: {e}"))?
                .unwrap_or(false);

            if !already_applied {
                tx.execute_batch(sql)
                    .map_err(|e| format!("Failed to apply migration {version} ({name}): {e}"))?;

                let now = now_timestamp();
                tx.execute(
                    "INSERT INTO schema_migrations (version, name, applied_at) VALUES (?1, ?2, ?3)",
                    params![version, name, now],
                )
                .map_err(|e| format!("Failed to record migration {version}: {e}"))?;
            }
        }

        tx.commit()
            .map_err(|e| format!("Failed to commit schema migrations: {e}"))?;
        Ok(())
    }

    // ==========================================
    // USER MANAGEMENT
    // ==========================================

    pub fn create_user(
        &self,
        username: &str,
        email: Option<&str>,
        password_hash: &str,
        role: &str,
    ) -> Result<UserRecord, String> {
        let username_trimmed = username.trim().to_lowercase();
        if username_trimmed.len() < 3 || username_trimmed.len() > 32 {
            return Err("Username must be between 3 and 32 characters.".to_string());
        }
        if !username_trimmed
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
        {
            return Err("Username may only contain letters, numbers, hyphens, and underscores.".to_string());
        }

        let email_normalized = email.map(|e| e.trim().to_lowercase()).filter(|e| !e.is_empty());
        if let Some(ref e) = email_normalized {
            if !e.contains('@') || e.len() > 128 {
                return Err("Please provide a valid email address.".to_string());
            }
        }

        if role != "user" && role != "admin" {
            return Err("Invalid role. Role must be 'user' or 'admin'.".to_string());
        }

        let user_id = generate_secure_id("usr");
        let now = now_timestamp();

        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO users (id, username, email, password_hash, role, is_verified, created_at, disabled_at)
             VALUES (?1, ?2, ?3, ?4, ?5, 1, ?6, NULL)",
            params![user_id, username_trimmed, email_normalized, password_hash, role, now],
        )
        .map_err(|e| {
            if e.to_string().contains("UNIQUE constraint failed") {
                "A user with that username or email already exists.".to_string()
            } else {
                format!("Failed to create user: {e}")
            }
        })?;

        Ok(UserRecord {
            id: user_id,
            username: username_trimmed,
            email: email_normalized,
            password_hash: password_hash.to_string(),
            role: role.to_string(),
            is_verified: true,
            created_at: now,
            disabled_at: None,
        })
    }

    pub fn get_user_by_username_or_email(&self, identity: &str) -> Result<Option<UserRecord>, String> {
        let ident = identity.trim().to_lowercase();
        let conn = self.conn.lock().map_err(|e| e.to_string())?;

        let mut stmt = conn
            .prepare(
                "SELECT id, username, email, password_hash, role, is_verified, created_at, disabled_at
                 FROM users
                 WHERE username = ?1 OR email = ?1
                 LIMIT 1",
            )
            .map_err(|e| e.to_string())?;

        let user = stmt
            .query_row(params![ident], |row| {
                Ok(UserRecord {
                    id: row.get(0)?,
                    username: row.get(1)?,
                    email: row.get(2)?,
                    password_hash: row.get(3)?,
                    role: row.get(4)?,
                    is_verified: row.get::<_, i64>(5)? != 0,
                    created_at: row.get(6)?,
                    disabled_at: row.get(7)?,
                })
            })
            .optional()
            .map_err(|e| e.to_string())?;

        Ok(user)
    }

    pub fn get_user_by_id(&self, user_id: &str) -> Result<Option<UserRecord>, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let mut stmt = conn
            .prepare(
                "SELECT id, username, email, password_hash, role, is_verified, created_at, disabled_at
                 FROM users
                 WHERE id = ?1
                 LIMIT 1",
            )
            .map_err(|e| e.to_string())?;

        let user = stmt
            .query_row(params![user_id], |row| {
                Ok(UserRecord {
                    id: row.get(0)?,
                    username: row.get(1)?,
                    email: row.get(2)?,
                    password_hash: row.get(3)?,
                    role: row.get(4)?,
                    is_verified: row.get::<_, i64>(5)? != 0,
                    created_at: row.get(6)?,
                    disabled_at: row.get(7)?,
                })
            })
            .optional()
            .map_err(|e| e.to_string())?;

        Ok(user)
    }

    pub fn has_admin_user(&self) -> Result<bool, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let count: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM users WHERE role = 'admin' AND disabled_at IS NULL",
                [],
                |row| row.get(0),
            )
            .map_err(|e| e.to_string())?;
        Ok(count > 0)
    }

    pub fn bootstrap_admin(
        &self,
        username: &str,
        email: Option<&str>,
        password: &str,
    ) -> Result<UserRecord, String> {
        if self.has_admin_user()? {
            return Err("An active administrator already exists in the system.".to_string());
        }
        let password_hash = hash_password(password)?;
        self.create_user(username, email, &password_hash, "admin")
    }

    // ==========================================
    // SESSIONS & CSRF
    // ==========================================

    pub fn create_session(
        &self,
        user_id: &str,
        token_digest: &str,
        csrf_token_digest: &str,
        ttl_seconds: i64,
    ) -> Result<SessionRecord, String> {
        let session_id = generate_secure_id("ses");
        let now = now_timestamp();
        let expires_at = now + ttl_seconds;

        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO sessions (id, user_id, token_digest, csrf_token_digest, created_at, last_seen_at, expires_at, revoked_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?5, ?6, NULL)",
            params![session_id, user_id, token_digest, csrf_token_digest, now, expires_at],
        )
        .map_err(|e| format!("Failed to create session: {e}"))?;

        Ok(SessionRecord {
            id: session_id,
            user_id: user_id.to_string(),
            token_digest: token_digest.to_string(),
            csrf_token_digest: csrf_token_digest.to_string(),
            created_at: now,
            last_seen_at: now,
            expires_at,
            revoked_at: None,
        })
    }

    pub fn get_valid_session_by_token_digest(&self, token_digest: &str) -> Result<Option<(SessionRecord, UserRecord)>, String> {
        let now = now_timestamp();
        let conn = self.conn.lock().map_err(|e| e.to_string())?;

        let mut stmt = conn
            .prepare(
                "SELECT s.id, s.user_id, s.token_digest, s.csrf_token_digest, s.created_at, s.last_seen_at, s.expires_at, s.revoked_at,
                        u.id, u.username, u.email, u.password_hash, u.role, u.is_verified, u.created_at, u.disabled_at
                 FROM sessions s
                 JOIN users u ON s.user_id = u.id
                 WHERE s.token_digest = ?1
                   AND s.revoked_at IS NULL
                   AND s.expires_at > ?2
                   AND u.disabled_at IS NULL
                 LIMIT 1",
            )
            .map_err(|e| e.to_string())?;

        let res = stmt
            .query_row(params![token_digest, now], |row| {
                let session = SessionRecord {
                    id: row.get(0)?,
                    user_id: row.get(1)?,
                    token_digest: row.get(2)?,
                    csrf_token_digest: row.get(3)?,
                    created_at: row.get(4)?,
                    last_seen_at: row.get(5)?,
                    expires_at: row.get(6)?,
                    revoked_at: row.get(7)?,
                };
                let user = UserRecord {
                    id: row.get(8)?,
                    username: row.get(9)?,
                    email: row.get(10)?,
                    password_hash: row.get(11)?,
                    role: row.get(12)?,
                    is_verified: row.get::<_, i64>(13)? != 0,
                    created_at: row.get(14)?,
                    disabled_at: row.get(15)?,
                };
                Ok((session, user))
            })
            .optional()
            .map_err(|e| e.to_string())?;

        Ok(res)
    }

    pub fn touch_session(&self, session_id: &str) -> Result<(), String> {
        let now = now_timestamp();
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "UPDATE sessions SET last_seen_at = ?1 WHERE id = ?2 AND revoked_at IS NULL",
            params![now, session_id],
        )
        .map_err(|e| format!("Failed to touch session: {e}"))?;
        Ok(())
    }

    pub fn update_session_csrf(&self, session_id: &str, new_csrf_digest: &str) -> Result<(), String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "UPDATE sessions SET csrf_token_digest = ?1 WHERE id = ?2 AND revoked_at IS NULL",
            params![new_csrf_digest, session_id],
        )
        .map_err(|e| format!("Failed to update session CSRF: {e}"))?;
        Ok(())
    }

    pub fn revoke_session(&self, session_id: &str) -> Result<(), String> {
        let now = now_timestamp();
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "UPDATE sessions SET revoked_at = ?1 WHERE id = ?2",
            params![now, session_id],
        )
        .map_err(|e| format!("Failed to revoke session: {e}"))?;
        Ok(())
    }

    pub fn revoke_all_user_sessions(&self, user_id: &str) -> Result<(), String> {
        let now = now_timestamp();
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "UPDATE sessions SET revoked_at = ?1 WHERE user_id = ?2 AND revoked_at IS NULL",
            params![now, user_id],
        )
        .map_err(|e| format!("Failed to revoke user sessions: {e}"))?;
        Ok(())
    }

    pub fn prune_expired_and_revoked_sessions(&self) -> Result<usize, String> {
        let now = now_timestamp();
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let affected = conn
            .execute(
                "DELETE FROM sessions WHERE expires_at < ?1 OR revoked_at IS NOT NULL",
                params![now],
            )
            .map_err(|e| format!("Failed to prune sessions: {e}"))?;
        Ok(affected)
    }

    // ==========================================
    // CONVERSATIONS & MESSAGES
    // ==========================================

    pub fn create_conversation(&self, user_id: &str, title: Option<&str>) -> Result<ConversationRecord, String> {
        let conv_id = generate_secure_id("cnv");
        let now = now_timestamp();
        let clean_title = title.map(|t| t.trim().to_string()).filter(|t| !t.is_empty());

        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO conversations (id, user_id, title, created_at, updated_at, deleted_at)
             VALUES (?1, ?2, ?3, ?4, ?4, NULL)",
            params![conv_id, user_id, clean_title, now],
        )
        .map_err(|e| format!("Failed to create conversation: {e}"))?;

        Ok(ConversationRecord {
            id: conv_id,
            user_id: user_id.to_string(),
            title: clean_title,
            created_at: now,
            updated_at: now,
        })
    }

    pub fn update_conversation_title(
        &self,
        conversation_id: &str,
        user_id: &str,
        title: &str,
    ) -> Result<bool, String> {
        let clean_title = title.trim();
        if clean_title.is_empty() {
            return Err("Title cannot be empty.".to_string());
        }
        let now = now_timestamp();
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let affected = conn
            .execute(
                "UPDATE conversations SET title = ?1, updated_at = ?2 WHERE id = ?3 AND user_id = ?4 AND deleted_at IS NULL",
                params![clean_title, now, conversation_id, user_id],
            )
            .map_err(|e| format!("Failed to update conversation title: {e}"))?;
        Ok(affected > 0)
    }

    pub fn list_conversations_for_user(&self, user_id: &str) -> Result<Vec<ConversationRecord>, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let mut stmt = conn
            .prepare(
                "SELECT c.id, c.user_id, c.title, c.created_at, c.updated_at,
                        (SELECT m.content FROM messages m WHERE m.conversation_id = c.id AND m.role = 'user' ORDER BY m.created_at ASC LIMIT 1)
                 FROM conversations c
                 WHERE c.user_id = ?1 AND c.deleted_at IS NULL
                 ORDER BY c.updated_at DESC",
            )
            .map_err(|e| e.to_string())?;

        let rows = stmt
            .query_map(params![user_id], |row| {
                let id: String = row.get(0)?;
                let user_id: String = row.get(1)?;
                let mut title: Option<String> = row.get(2)?;
                let created_at: i64 = row.get(3)?;
                let updated_at: i64 = row.get(4)?;
                let first_msg: Option<String> = row.get(5)?;

                let is_default = title.as_deref().map_or(true, |t| {
                    let lt = t.trim().to_lowercase();
                    lt.is_empty() || lt == "new conversation" || lt == "new chat"
                });

                if is_default {
                    if let Some(msg) = first_msg {
                        title = Some(generate_specific_conversation_title(&msg));
                    }
                }

                Ok(ConversationRecord {
                    id,
                    user_id,
                    title,
                    created_at,
                    updated_at,
                })
            })
            .map_err(|e| e.to_string())?;

        let mut results = Vec::new();
        for r in rows {
            results.push(r.map_err(|e| e.to_string())?);
        }
        Ok(results)
    }

    pub fn get_conversation_for_user(&self, conversation_id: &str, user_id: &str) -> Result<Option<ConversationRecord>, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let mut stmt = conn
            .prepare(
                "SELECT c.id, c.user_id, c.title, c.created_at, c.updated_at,
                        (SELECT m.content FROM messages m WHERE m.conversation_id = c.id AND m.role = 'user' ORDER BY m.created_at ASC LIMIT 1)
                 FROM conversations c
                 WHERE c.id = ?1 AND c.user_id = ?2 AND c.deleted_at IS NULL
                 LIMIT 1",
            )
            .map_err(|e| e.to_string())?;

        let conv = stmt
            .query_row(params![conversation_id, user_id], |row| {
                let id: String = row.get(0)?;
                let user_id: String = row.get(1)?;
                let mut title: Option<String> = row.get(2)?;
                let created_at: i64 = row.get(3)?;
                let updated_at: i64 = row.get(4)?;
                let first_msg: Option<String> = row.get(5)?;

                let is_default = title.as_deref().map_or(true, |t| {
                    let lt = t.trim().to_lowercase();
                    lt.is_empty() || lt == "new conversation" || lt == "new chat"
                });

                if is_default {
                    if let Some(msg) = first_msg {
                        title = Some(generate_specific_conversation_title(&msg));
                    }
                }

                Ok(ConversationRecord {
                    id,
                    user_id,
                    title,
                    created_at,
                    updated_at,
                })
            })
            .optional()
            .map_err(|e| e.to_string())?;

        Ok(conv)
    }

    pub fn delete_conversation_for_user(&self, conversation_id: &str, user_id: &str) -> Result<bool, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let affected = conn
            .execute(
                "DELETE FROM conversations WHERE id = ?1 AND user_id = ?2",
                params![conversation_id, user_id],
            )
            .map_err(|e| format!("Failed to delete conversation: {e}"))?;

        Ok(affected > 0)
    }
}

fn title_case_word(w: &str) -> String {
    let mut chars = w.chars();
    match chars.next() {
        None => String::new(),
        Some(f) => f.to_uppercase().collect::<String>() + &chars.as_str().to_lowercase(),
    }
}

fn title_case_phrase(phrase: &str) -> String {
    let words: Vec<&str> = phrase.split_whitespace().collect();
    let mut formatted = Vec::new();
    for (i, &w) in words.iter().enumerate() {
        let low = w.to_lowercase();
        match low.as_str() {
            "tps" => formatted.push("TPS".to_string()),
            "btc" => formatted.push("BTC".to_string()),
            "eth" => formatted.push("ETH".to_string()),
            "sol" => formatted.push("SOL".to_string()),
            "xrp" => formatted.push("XRP".to_string()),
            "ai" => formatted.push("AI".to_string()),
            "api" => formatted.push("API".to_string()),
            "sql" => formatted.push("SQL".to_string()),
            "sqlite" => formatted.push("SQLite".to_string()),
            "ui" => formatted.push("UI".to_string()),
            "usd" => formatted.push("USD".to_string()),
            "eur" => formatted.push("EUR".to_string()),
            "pkr" => formatted.push("PKR".to_string()),
            "inr" => formatted.push("INR".to_string()),
            "gbp" => formatted.push("GBP".to_string()),
            "html" => formatted.push("HTML".to_string()),
            "css" => formatted.push("CSS".to_string()),
            "js" => formatted.push("JS".to_string()),
            "rust" => formatted.push("Rust".to_string()),
            "python" => formatted.push("Python".to_string()),
            "solana" => formatted.push("Solana".to_string()),
            "bitcoin" => formatted.push("Bitcoin".to_string()),
            "ethereum" => formatted.push("Ethereum".to_string()),
            "america" | "us" => formatted.push("US".to_string()),
            "usa" => formatted.push("USA".to_string()),
            _ => {
                if i > 0
                    && matches!(
                        low.as_str(),
                        "in" | "on" | "at" | "of" | "for" | "to" | "vs" | "by" | "with" | "and"
                    )
                {
                    formatted.push(low);
                } else {
                    formatted.push(title_case_word(w));
                }
            }
        }
    }
    formatted.join(" ")
}

pub fn generate_specific_conversation_title(prompt: &str) -> String {
    let trimmed = prompt.trim();
    if trimmed.is_empty() {
        return "New Chat".to_string();
    }

    let lower = trimmed.to_lowercase();

    // 1. Math queries
    if lower
        .chars()
        .all(|c| c.is_ascii_digit() || " +-/*^().%".contains(c))
        && trimmed.len() <= 30
    {
        return format!("Math: {}", trimmed);
    }
    for prefix in &["solve ", "calculate ", "compute ", "evaluate "] {
        if lower.starts_with(prefix) {
            let expr = trimmed[prefix.len()..].trim();
            if expr.len() <= 25 && expr.chars().any(|c| "+-*/".contains(c)) {
                return format!("Math: {}", expr);
            }
        }
    }

    // 2. Greetings
    let greeting_tokens = [
        "hi",
        "hello",
        "hey",
        "greetings",
        "good morning",
        "good evening",
        "good afternoon",
        "howdy",
        "sup",
        "yo",
        "hello there",
        "hi there",
        "hey there",
    ];
    let stripped_greeting = lower
        .trim_end_matches(|c: char| c.is_ascii_punctuation() || c.is_whitespace());
    if greeting_tokens.contains(&stripped_greeting) {
        return "Greetings".to_string();
    }

    // 3. Bot capabilities / help
    let cap_tokens = [
        "what can you do",
        "who are you",
        "help",
        "capabilities",
        "what are your features",
        "how do you work",
        "what is rustbot",
        "introduce yourself",
    ];
    if cap_tokens.contains(&stripped_greeting) {
        return "Bot Capabilities".to_string();
    }

    // 4. Clean conversational prefixes
    let prefixes = [
        "can you please explain to me about ",
        "can you explain to me about ",
        "can you please explain to me ",
        "can you explain to me ",
        "can you please explain how ",
        "can you please explain what ",
        "can you please explain why ",
        "can you please explain the ",
        "can you please explain ",
        "can you explain how ",
        "can you explain what ",
        "can you explain why ",
        "can you explain the ",
        "can you explain ",
        "could you please explain ",
        "could you explain ",
        "can you tell me about ",
        "can you tell me what ",
        "can you tell me how ",
        "can you tell me ",
        "could you tell me about ",
        "could you tell me ",
        "tell me about ",
        "i want to know about ",
        "i want to know ",
        "what do you know about ",
        "what can you tell me about ",
        "let's discuss about ",
        "let's discuss ",
        "let s discuss about ",
        "let s discuss ",
        "lets discuss about ",
        "lets discuss ",
        "write an argumentative essay on whether ",
        "write an argumentative essay on ",
        "write an essay on whether ",
        "write an essay on ",
        "write a blog post about ",
        "write a story about ",
        "write a ",
        "create a ",
        "how do i calculate the ",
        "how do i calculate ",
        "how do we calculate ",
        "how do you calculate ",
        "how do i ",
        "how do we ",
        "how do you ",
        "how to ",
        "how does ",
        "how can i ",
        "how can we ",
        "how high can ",
        "give me an overview of ",
        "give me a summary of ",
        "give me an ",
        "give me a ",
        "give me ",
        "show me ",
        "what is the difference between ",
        "difference between ",
        "what is the name of the ",
        "what is the name of ",
        "what is the ",
        "what are the ",
        "what was the ",
        "what were the ",
        "what is ",
        "what are ",
        "what was ",
        "what were ",
        "why does ",
        "why is the ",
        "why is ",
        "why are ",
        "who is the ",
        "who was the ",
        "who is ",
        "who was ",
        "analyze ",
        "analysis of ",
        "predict ",
        "explain how ",
        "explain what ",
        "explain why ",
        "explain the ",
        "explain ",
        "please ",
    ];

    let mut cleaned = trimmed;
    let mut found = true;
    while found {
        found = false;
        let c_lower = cleaned.to_lowercase();
        for p in &prefixes {
            if c_lower.starts_with(p) {
                cleaned = cleaned[p.len()..].trim_start();
                found = true;
                break;
            }
        }
    }

    // 5. Clean trailing conversational phrases
    let trailing = [
        " about and how does it work",
        " and how does it work",
        " and how it works",
        " how it works",
        " works",
        " right now",
        " in detail",
        " step by step",
        " for me",
        " please",
        " thanks",
        " thank you",
        " or down according to market sentiment",
        " according to market sentiment",
        " should be allowed in school",
        " should be allowed",
        " should be",
    ];
    let mut trailing_found = true;
    while trailing_found {
        trailing_found = false;
        let c_lower = cleaned.to_lowercase();
        let stripped_punct =
            c_lower.trim_end_matches(|c: char| c.is_ascii_punctuation() || c.is_whitespace());
        for t in &trailing {
            if stripped_punct.ends_with(t) {
                let cutoff = stripped_punct.len() - t.len();
                cleaned = cleaned[..cutoff].trim_end();
                trailing_found = true;
                break;
            }
        }
    }

    // Strip trailing punctuation
    let cleaned = cleaned.trim_end_matches(|c: char| c.is_ascii_punctuation() || c.is_whitespace());

    // 6. Comparison pattern: "X and Y"
    if let Some((left, right)) = cleaned.split_once(" and ") {
        let left_words: Vec<&str> = left.split_whitespace().collect();
        let right_words: Vec<&str> = right.split_whitespace().collect();
        if !left_words.is_empty()
            && left_words.len() <= 3
            && !right_words.is_empty()
            && right_words.len() <= 3
        {
            return format!(
                "{} vs {}",
                title_case_phrase(left),
                title_case_phrase(right)
            );
        }
    }

    // 7. Weather queries: "weather in <Location>" -> "<Location> Weather"
    let c_lower = cleaned.to_lowercase();
    if c_lower.starts_with("weather in ") {
        let loc = cleaned[11..].trim();
        if !loc.is_empty() {
            return format!("{} Weather", title_case_phrase(loc));
        }
    }

    // 8. Tokenize into words and drop initial noise words
    let words: Vec<&str> = cleaned
        .split_whitespace()
        .map(|w| w.trim_matches(|c: char| c.is_ascii_punctuation()))
        .filter(|w| !w.is_empty())
        .collect();

    let mut start_idx = 0;
    while start_idx < words.len()
        && matches!(
            words[start_idx].to_lowercase().as_str(),
            "the" | "a" | "an" | "about" | "of" | "to" | "in"
        )
    {
        start_idx += 1;
    }

    let meaningful_words = if start_idx < words.len() {
        &words[start_idx..]
    } else {
        &words[..]
    };

    if meaningful_words.is_empty() {
        return "General Discussion".to_string();
    }

    // Target 2 to 4 concise words (max 28 characters total)
    let mut selected_words = Vec::new();
    let mut total_chars = 0;
    for &w in meaningful_words.iter().take(5) {
        if total_chars + w.len() > 28 && selected_words.len() >= 2 {
            break;
        }
        selected_words.push(w);
        total_chars += w.len() + 1;
    }

    // Remove dangling trailing prepositions/conjunctions/auxiliary verbs
    let dangling = [
        "in", "on", "at", "of", "for", "to", "vs", "by", "with", "and", "or", "the", "a",
        "an", "is", "be", "about", "should", "would", "could", "can", "will", "must",
        "might", "do", "does", "did", "have", "has", "had",
    ];
    while selected_words.len() > 1
        && dangling.contains(&selected_words.last().unwrap().to_lowercase().as_str())
    {
        selected_words.pop();
    }

    // Format words with proper capitalization
    let mut formatted_words = Vec::new();
    for (i, &w) in selected_words.iter().enumerate() {
        let low = w.to_lowercase();
        match low.as_str() {
            "tps" => formatted_words.push("TPS".to_string()),
            "btc" => formatted_words.push("BTC".to_string()),
            "eth" => formatted_words.push("ETH".to_string()),
            "sol" => formatted_words.push("SOL".to_string()),
            "xrp" => formatted_words.push("XRP".to_string()),
            "ai" => formatted_words.push("AI".to_string()),
            "api" => formatted_words.push("API".to_string()),
            "sql" => formatted_words.push("SQL".to_string()),
            "sqlite" => formatted_words.push("SQLite".to_string()),
            "ui" => formatted_words.push("UI".to_string()),
            "usd" => formatted_words.push("USD".to_string()),
            "eur" => formatted_words.push("EUR".to_string()),
            "pkr" => formatted_words.push("PKR".to_string()),
            "inr" => formatted_words.push("INR".to_string()),
            "gbp" => formatted_words.push("GBP".to_string()),
            "html" => formatted_words.push("HTML".to_string()),
            "css" => formatted_words.push("CSS".to_string()),
            "js" => formatted_words.push("JS".to_string()),
            "rust" => formatted_words.push("Rust".to_string()),
            "python" => formatted_words.push("Python".to_string()),
            "solana" => formatted_words.push("Solana".to_string()),
            "bitcoin" => formatted_words.push("Bitcoin".to_string()),
            "ethereum" => formatted_words.push("Ethereum".to_string()),
            "america" | "us" => formatted_words.push("US".to_string()),
            "usa" => formatted_words.push("USA".to_string()),
            _ => {
                if i > 0
                    && matches!(
                        low.as_str(),
                        "in" | "on" | "at" | "of" | "for" | "to" | "vs" | "by" | "with" | "and"
                    )
                {
                    formatted_words.push(low);
                } else {
                    formatted_words.push(title_case_word(w));
                }
            }
        }
    }

    let title = formatted_words.join(" ");
    if title.is_empty() {
        "New Chat".to_string()
    } else {
        title
    }
}

impl Database {

    pub fn add_message(
        &self,
        conversation_id: &str,
        user_id: &str,
        role: &str,
        content: &str,
        status: Option<&str>,
    ) -> Result<MessageRecord, String> {
        if role != "user" && role != "assistant" && role != "system" {
            return Err("Invalid message role. Must be 'user', 'assistant', or 'system'.".to_string());
        }

        let mut conn = self.conn.lock().map_err(|e| e.to_string())?;
        let tx = conn.transaction().map_err(|e| e.to_string())?;

        // 1. Verify ownership
        let belongs: bool = tx
            .query_row(
                "SELECT 1 FROM conversations WHERE id = ?1 AND user_id = ?2 AND deleted_at IS NULL",
                params![conversation_id, user_id],
                |_| Ok(true),
            )
            .optional()
            .map_err(|e| e.to_string())?
            .unwrap_or(false);

        if !belongs {
            return Err("Conversation not found or access denied.".to_string());
        }

        let msg_id = generate_secure_id("msg");
        let now = now_timestamp();

        tx.execute(
            "INSERT INTO messages (id, conversation_id, role, content, status, created_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
            params![msg_id, conversation_id, role, content, status, now],
        )
        .map_err(|e| format!("Failed to insert message: {e}"))?;

        // 2. Update conversation timestamp
        tx.execute(
            "UPDATE conversations SET updated_at = ?1 WHERE id = ?2",
            params![now, conversation_id],
        )
        .map_err(|e| format!("Failed to update conversation timestamp: {e}"))?;

        tx.commit().map_err(|e| e.to_string())?;

        Ok(MessageRecord {
            id: msg_id,
            conversation_id: conversation_id.to_string(),
            role: role.to_string(),
            content: content.to_string(),
            status: status.map(|s| s.to_string()),
            created_at: now,
        })
    }

    pub fn list_messages_for_conversation(
        &self,
        conversation_id: &str,
        user_id: &str,
    ) -> Result<Vec<MessageRecord>, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;

        // Check ownership first
        let belongs: bool = conn
            .query_row(
                "SELECT 1 FROM conversations WHERE id = ?1 AND user_id = ?2 AND deleted_at IS NULL",
                params![conversation_id, user_id],
                |_| Ok(true),
            )
            .optional()
            .map_err(|e| e.to_string())?
            .unwrap_or(false);

        if !belongs {
            return Err("Conversation not found or access denied.".to_string());
        }

        let mut stmt = conn
            .prepare(
                "SELECT id, conversation_id, role, content, status, created_at
                 FROM messages
                 WHERE conversation_id = ?1
                 ORDER BY created_at ASC",
            )
            .map_err(|e| e.to_string())?;

        let rows = stmt
            .query_map(params![conversation_id], |row| {
                Ok(MessageRecord {
                    id: row.get(0)?,
                    conversation_id: row.get(1)?,
                    role: row.get(2)?,
                    content: row.get(3)?,
                    status: row.get(4)?,
                    created_at: row.get(5)?,
                })
            })
            .map_err(|e| e.to_string())?;

        let mut results = Vec::new();
        for r in rows {
            results.push(r.map_err(|e| e.to_string())?);
        }
        Ok(results)
    }

    // ==========================================
    // MEMORIES / KNOWLEDGE BASE
    // ==========================================

    pub fn list_memories(&self) -> Result<Vec<MemoryRecord>, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let mut stmt = conn
            .prepare(
                "SELECT id, keywords, response, match_mode, category, created_at, updated_at, owner_user_id, updated_by_user_id
                 FROM memories
                 ORDER BY id ASC",
            )
            .map_err(|e| e.to_string())?;

        let rows = stmt
            .query_map([], |row| {
                let keywords_raw: String = row.get(1)?;
                let keywords: Vec<String> = serde_json::from_str(&keywords_raw).unwrap_or_default();
                Ok(MemoryRecord {
                    id: row.get(0)?,
                    keywords,
                    response: row.get(2)?,
                    match_mode: row.get(3)?,
                    category: row.get(4)?,
                    created_at: row.get(5)?,
                    updated_at: row.get(6)?,
                    owner_user_id: row.get(7)?,
                    updated_by_user_id: row.get(8)?,
                })
            })
            .map_err(|e| e.to_string())?;

        let mut results = Vec::new();
        for r in rows {
            results.push(r.map_err(|e| e.to_string())?);
        }
        Ok(results)
    }

    pub fn get_memory_by_id(&self, id: i64) -> Result<Option<MemoryRecord>, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let mut stmt = conn
            .prepare(
                "SELECT id, keywords, response, match_mode, category, created_at, updated_at, owner_user_id, updated_by_user_id
                 FROM memories
                 WHERE id = ?1
                 LIMIT 1",
            )
            .map_err(|e| e.to_string())?;

        let res = stmt
            .query_row(params![id], |row| {
                let keywords_raw: String = row.get(1)?;
                let keywords: Vec<String> = serde_json::from_str(&keywords_raw).unwrap_or_default();
                Ok(MemoryRecord {
                    id: row.get(0)?,
                    keywords,
                    response: row.get(2)?,
                    match_mode: row.get(3)?,
                    category: row.get(4)?,
                    created_at: row.get(5)?,
                    updated_at: row.get(6)?,
                    owner_user_id: row.get(7)?,
                    updated_by_user_id: row.get(8)?,
                })
            })
            .optional()
            .map_err(|e| e.to_string())?;

        Ok(res)
    }

    pub fn insert_memory(
        &self,
        keywords: &[String],
        response: &str,
        match_mode: &str,
        category: &str,
        user_id: Option<&str>,
    ) -> Result<MemoryRecord, String> {
        if keywords.is_empty() {
            return Err("Memory must contain at least one keyword.".to_string());
        }
        if response.trim().is_empty() {
            return Err("Memory response cannot be empty.".to_string());
        }

        let keywords_json = serde_json::to_string(keywords)
            .map_err(|e| format!("Failed to serialize keywords: {e}"))?;
        let now = now_timestamp();

        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO memories (keywords, response, match_mode, category, created_at, updated_at, owner_user_id, updated_by_user_id)
             VALUES (?1, ?2, ?3, ?4, ?5, ?5, ?6, ?6)",
            params![keywords_json, response, match_mode, category, now, user_id],
        )
        .map_err(|e| format!("Failed to insert memory: {e}"))?;

        let id = conn.last_insert_rowid();

        Ok(MemoryRecord {
            id,
            keywords: keywords.to_vec(),
            response: response.to_string(),
            match_mode: match_mode.to_string(),
            category: category.to_string(),
            created_at: now,
            updated_at: now,
            owner_user_id: user_id.map(|u| u.to_string()),
            updated_by_user_id: user_id.map(|u| u.to_string()),
        })
    }

    pub fn insert_memory_with_id(
        &self,
        id: i64,
        keywords: &[String],
        response: &str,
        match_mode: &str,
        category: &str,
        user_id: Option<&str>,
    ) -> Result<MemoryRecord, String> {
        if keywords.is_empty() {
            return Err("Memory must contain at least one keyword.".to_string());
        }
        if response.trim().is_empty() {
            return Err("Memory response cannot be empty.".to_string());
        }

        let keywords_json = serde_json::to_string(keywords)
            .map_err(|e| format!("Failed to serialize keywords: {e}"))?;
        let now = now_timestamp();

        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO memories (id, keywords, response, match_mode, category, created_at, updated_at, owner_user_id, updated_by_user_id)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?6, ?7, ?7)",
            params![id, keywords_json, response, match_mode, category, now, user_id],
        )
        .map_err(|e| format!("Failed to insert memory #{id}: {e}"))?;

        Ok(MemoryRecord {
            id,
            keywords: keywords.to_vec(),
            response: response.to_string(),
            match_mode: match_mode.to_string(),
            category: category.to_string(),
            created_at: now,
            updated_at: now,
            owner_user_id: user_id.map(|u| u.to_string()),
            updated_by_user_id: user_id.map(|u| u.to_string()),
        })
    }

    pub fn update_memory(
        &self,
        id: i64,
        keywords: &[String],
        response: &str,
        match_mode: &str,
        category: &str,
        user_id: Option<&str>,
    ) -> Result<MemoryRecord, String> {
        if keywords.is_empty() {
            return Err("Memory must contain at least one keyword.".to_string());
        }
        if response.trim().is_empty() {
            return Err("Memory response cannot be empty.".to_string());
        }

        let keywords_json = serde_json::to_string(keywords)
            .map_err(|e| format!("Failed to serialize keywords: {e}"))?;
        let now = now_timestamp();

        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let affected = conn
            .execute(
                "UPDATE memories
                 SET keywords = ?1, response = ?2, match_mode = ?3, category = ?4, updated_at = ?5, updated_by_user_id = ?6
                 WHERE id = ?7",
                params![keywords_json, response, match_mode, category, now, user_id, id],
            )
            .map_err(|e| format!("Failed to update memory: {e}"))?;

        if affected == 0 {
            return Err(format!("Memory #{id} not found."));
        }

        // Fetch created_at and owner_user_id
        let (created_at, owner_user_id): (i64, Option<String>) = conn
            .query_row(
                "SELECT created_at, owner_user_id FROM memories WHERE id = ?1",
                params![id],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .map_err(|e| e.to_string())?;

        Ok(MemoryRecord {
            id,
            keywords: keywords.to_vec(),
            response: response.to_string(),
            match_mode: match_mode.to_string(),
            category: category.to_string(),
            created_at,
            updated_at: now,
            owner_user_id,
            updated_by_user_id: user_id.map(|u| u.to_string()),
        })
    }

    pub fn delete_memory(&self, id: i64) -> Result<bool, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let affected = conn
            .execute("DELETE FROM memories WHERE id = ?1", params![id])
            .map_err(|e| format!("Failed to delete memory #{id}: {e}"))?;
        Ok(affected > 0)
    }

    /// Import memories from an existing `knowledge.json` file in one atomic transaction.
    /// Supports both wrapped `{"patterns": [...]}` and raw list `[...]` formats,
    /// and avoids inserting duplicates if a pattern with matching normalized keywords already exists.
    pub fn import_memories_from_json(&self, path: &Path) -> Result<ImportStats, String> {
        if !path.exists() {
            return Ok(ImportStats {
                total_read: 0,
                inserted: 0,
                skipped: 0,
                rejected: 0,
            });
        }

        let raw = std::fs::read_to_string(path)
            .map_err(|e| format!("Failed to read knowledge file {:?}: {e}", path))?;

        #[derive(Deserialize)]
        struct RawPattern {
            keywords: Vec<String>,
            response: String,
            #[serde(default = "default_match_mode")]
            match_mode: String,
            #[serde(default = "default_category")]
            category: String,
        }

        fn default_match_mode() -> String {
            "phrase".to_string()
        }
        fn default_category() -> String {
            "general".to_string()
        }

        #[derive(Deserialize)]
        #[serde(untagged)]
        enum RawKnowledgePayload {
            Wrapped { patterns: Vec<RawPattern> },
            List(Vec<RawPattern>),
        }

        let patterns = match serde_json::from_str::<RawKnowledgePayload>(&raw) {
            Ok(RawKnowledgePayload::Wrapped { patterns }) => patterns,
            Ok(RawKnowledgePayload::List(patterns)) => patterns,
            Err(e) => return Err(format!("Failed to parse knowledge json: {e}")),
        };

        let total_read = patterns.len();
        let mut inserted = 0;
        let mut skipped = 0;
        let mut rejected = 0;
        let now = now_timestamp();

        let mut conn = self.conn.lock().map_err(|e| e.to_string())?;
        let tx = conn.transaction().map_err(|e| e.to_string())?;

        // Query existing keyword sets from memories table to prevent duplicate insertion
        let mut existing_keyword_sets: std::collections::HashSet<Vec<String>> =
            std::collections::HashSet::new();
        {
            let mut stmt = tx
                .prepare("SELECT keywords FROM memories")
                .map_err(|e| format!("Failed to query existing memories: {e}"))?;
            let rows = stmt
                .query_map([], |row| {
                    let kw_raw: String = row.get(0)?;
                    let mut kws: Vec<String> = serde_json::from_str(&kw_raw).unwrap_or_default();
                    kws.sort();
                    Ok(kws)
                })
                .map_err(|e| e.to_string())?;

            for r in rows {
                if let Ok(kws) = r {
                    if !kws.is_empty() {
                        existing_keyword_sets.insert(kws);
                    }
                }
            }
        }

        for p in patterns {
            let mut clean_keywords: Vec<String> = Vec::new();
            for k in p.keywords {
                let norm = k.trim().to_lowercase();
                if !norm.is_empty() && !clean_keywords.contains(&norm) {
                    clean_keywords.push(norm);
                }
            }

            if clean_keywords.is_empty() || p.response.trim().is_empty() {
                rejected += 1;
                continue;
            }

            let mut sort_key = clean_keywords.clone();
            sort_key.sort();
            if existing_keyword_sets.contains(&sort_key) {
                skipped += 1;
                continue;
            }

            let kw_json = match serde_json::to_string(&clean_keywords) {
                Ok(j) => j,
                Err(_) => {
                    rejected += 1;
                    continue;
                }
            };

            let match_mode = if p.match_mode.trim().is_empty() {
                "phrase"
            } else {
                p.match_mode.trim()
            };

            let category = if p.category.trim().is_empty() {
                "general"
            } else {
                p.category.trim()
            };

            let res = tx.execute(
                "INSERT INTO memories (keywords, response, match_mode, category, created_at, updated_at, updated_by_user_id)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?5, NULL)",
                params![kw_json, p.response.trim(), match_mode, category, now],
            );

            match res {
                Ok(_) => {
                    existing_keyword_sets.insert(sort_key);
                    inserted += 1;
                }
                Err(_) => rejected += 1,
            }
        }

        tx.commit().map_err(|e| format!("Failed to commit imported memories: {e}"))?;

        Ok(ImportStats {
            total_read,
            inserted,
            skipped,
            rejected,
        })
    }

    // ==========================================
    // AI USAGE & QUOTA LIMITS
    // ==========================================

    pub fn record_ai_usage(
        &self,
        user_id: &str,
        model: &str,
        input_tokens: Option<i64>,
        output_tokens: Option<i64>,
        request_status: &str,
    ) -> Result<String, String> {
        let usage_id = generate_secure_id("usg");
        let now = now_timestamp();

        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO ai_usage (id, user_id, occurred_at, model, input_tokens, output_tokens, request_status)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
            params![usage_id, user_id, now, model, input_tokens, output_tokens, request_status],
        )
        .map_err(|e| format!("Failed to record AI usage: {e}"))?;

        Ok(usage_id)
    }

    pub fn count_user_requests_since(&self, user_id: &str, since_timestamp: i64) -> Result<i64, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let count: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM ai_usage WHERE user_id = ?1 AND occurred_at >= ?2",
                params![user_id, since_timestamp],
                |row| row.get(0),
            )
            .map_err(|e| e.to_string())?;
        Ok(count)
    }

    pub fn count_global_requests_since(&self, since_timestamp: i64) -> Result<i64, String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;
        let count: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM ai_usage WHERE occurred_at >= ?1",
                params![since_timestamp],
                |row| row.get(0),
            )
            .map_err(|e| e.to_string())?;
        Ok(count)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_password_hashing_and_verification() {
        let pass = "CorrectHorseBattery99!";
        let hash = hash_password(pass).expect("Should hash password");
        assert!(verify_password(pass, &hash));
        assert!(!verify_password("WrongPassword123!", &hash));
    }

    #[test]
    fn test_token_digest_and_constant_time_comparison() {
        let token = generate_secure_token();
        let pepper = "test-pepper-123";
        let digest1 = digest_token(&token, pepper);
        let digest2 = digest_token(&token, pepper);
        assert_eq!(digest1, digest2);
        assert!(constant_time_eq_str(&digest1, &digest2));
        assert!(!constant_time_eq_str(&digest1, "different-hash-value"));
    }

    #[test]
    fn test_database_migrations_and_user_creation() {
        let db = Database::open_in_memory().expect("Should create in-memory database");
        assert!(!db.has_admin_user().unwrap());

        // Create normal user
        let pass_hash = hash_password("Secret12345!").unwrap();
        let user = db
            .create_user("alice", Some("alice@example.com"), &pass_hash, "user")
            .expect("Should create user");
        assert_eq!(user.username, "alice");
        assert_eq!(user.role, "user");

        // Duplicate username should fail
        let dup_res = db.create_user("Alice", Some("alice2@example.com"), &pass_hash, "user");
        assert!(dup_res.is_err());

        // Bootstrap Admin
        let admin = db
            .bootstrap_admin("rootadmin", Some("admin@example.com"), "AdminSecretPass123!")
            .expect("Should bootstrap admin");
        assert_eq!(admin.role, "admin");
        assert!(db.has_admin_user().unwrap());

        // Second bootstrap admin must be refused
        let second_bootstrap = db.bootstrap_admin("root2", None, "AnotherSecret123!");
        assert!(second_bootstrap.is_err());
    }

    #[test]
    fn test_sessions_and_revocation() {
        let db = Database::open_in_memory().unwrap();
        let pass_hash = hash_password("Password123!").unwrap();
        let user = db.create_user("bob", None, &pass_hash, "user").unwrap();

        let raw_token = generate_secure_token();
        let token_digest = digest_token(&raw_token, "");
        let csrf_token = generate_secure_token();
        let csrf_digest = digest_token(&csrf_token, "");

        let session = db
            .create_session(&user.id, &token_digest, &csrf_digest, 3600)
            .unwrap();

        // Valid lookup
        let found = db.get_valid_session_by_token_digest(&token_digest).unwrap();
        assert!(found.is_some());
        let (s, u) = found.unwrap();
        assert_eq!(s.id, session.id);
        assert_eq!(u.id, user.id);

        // Revocation
        db.revoke_session(&session.id).unwrap();
        let after_revocation = db.get_valid_session_by_token_digest(&token_digest).unwrap();
        assert!(after_revocation.is_none());

        // Pruning removes the revoked session from the table
        let pruned = db.prune_expired_and_revoked_sessions().unwrap();
        assert_eq!(pruned, 1);
        let pruned_again = db.prune_expired_and_revoked_sessions().unwrap();
        assert_eq!(pruned_again, 0);
    }

    #[test]
    fn test_conversation_and_message_isolation() {
        let db = Database::open_in_memory().unwrap();
        let pass_hash = hash_password("PassWord123!").unwrap();
        let alice = db.create_user("alice", None, &pass_hash, "user").unwrap();
        let bob = db.create_user("bob", None, &pass_hash, "user").unwrap();

        // Alice creates conversation
        let alice_conv = db
            .create_conversation(&alice.id, Some("Alice Private Chat"))
            .unwrap();

        // Alice adds message
        let msg = db
            .add_message(&alice_conv.id, &alice.id, "user", "Hello from Alice", None)
            .unwrap();
        assert_eq!(msg.content, "Hello from Alice");

        // Bob cannot view Alice's conversation
        let bob_view = db.get_conversation_for_user(&alice_conv.id, &bob.id).unwrap();
        assert!(bob_view.is_none());

        // Bob cannot list messages in Alice's conversation
        let bob_messages = db.list_messages_for_conversation(&alice_conv.id, &bob.id);
        assert!(bob_messages.is_err());

        // Bob cannot add a message to Alice's conversation
        let bob_add = db.add_message(&alice_conv.id, &bob.id, "user", "Hacked!", None);
        assert!(bob_add.is_err());

        // Bob cannot delete Alice's conversation
        let bob_del = db.delete_conversation_for_user(&alice_conv.id, &bob.id).unwrap();
        assert!(!bob_del);

        // Alice's data still intact
        let alice_messages = db
            .list_messages_for_conversation(&alice_conv.id, &alice.id)
            .unwrap();
        assert_eq!(alice_messages.len(), 1);
        assert_eq!(alice_messages[0].content, "Hello from Alice");
    }

    #[test]
    fn test_memory_crud_and_import() {
        let db = Database::open_in_memory().unwrap();
        let pass_hash = hash_password("PassWord123!").unwrap();
        let alice = db.create_user("alice", None, &pass_hash, "user").unwrap();
        let bob = db.create_user("bob", None, &pass_hash, "admin").unwrap();

        let memory = db
            .insert_memory(
                &["hello".to_string(), "hi".to_string()],
                "Greetings human!",
                "phrase",
                "general",
                Some(&alice.id),
            )
            .unwrap();
        assert_eq!(memory.keywords, vec!["hello", "hi"]);
        assert_eq!(memory.owner_user_id.as_deref(), Some(alice.id.as_str()));
        assert_eq!(memory.updated_by_user_id.as_deref(), Some(alice.id.as_str()));

        let found = db.get_memory_by_id(memory.id).unwrap();
        assert!(found.is_some());
        assert_eq!(found.unwrap().owner_user_id.as_deref(), Some(alice.id.as_str()));

        let all = db.list_memories().unwrap();
        assert_eq!(all.len(), 1);
        assert_eq!(all[0].owner_user_id.as_deref(), Some(alice.id.as_str()));

        let updated = db
            .update_memory(
                memory.id,
                &["hello".to_string(), "hey".to_string()],
                "Updated greeting",
                "phrase",
                "greetings",
                Some(&bob.id),
            )
            .unwrap();
        assert_eq!(updated.response, "Updated greeting");
        assert_eq!(updated.category, "greetings");
        assert_eq!(updated.owner_user_id.as_deref(), Some(alice.id.as_str()));
        assert_eq!(updated.updated_by_user_id.as_deref(), Some(bob.id.as_str()));

        let deleted = db.delete_memory(memory.id).unwrap();
        assert!(deleted);
        assert_eq!(db.list_memories().unwrap().len(), 0);
        assert!(db.get_memory_by_id(memory.id).unwrap().is_none());
    }

    #[test]
    fn test_import_memories_from_json_wrapped_and_deduplication() {
        let db = Database::open_in_memory().unwrap();
        db.insert_memory(
            &["rust".to_string()],
            "Rust language original response",
            "phrase",
            "general",
            None,
        )
        .unwrap();

        let temp_dir = std::env::temp_dir();
        let json_path = temp_dir.join(format!("test_knowledge_{}.json", now_timestamp()));

        let test_json = r#"{
            "patterns": [
                {
                    "id": 1,
                    "keywords": ["rust"],
                    "response": "Duplicate rust definition that should be skipped",
                    "match_mode": "all",
                    "category": "general"
                },
                {
                    "id": 2,
                    "keywords": ["cargo", "build"],
                    "response": "Cargo is the Rust package manager.",
                    "match_mode": "all",
                    "category": "tooling"
                },
                {
                    "id": 3,
                    "keywords": [],
                    "response": "Should be rejected because keywords are empty",
                    "match_mode": "all",
                    "category": "tooling"
                }
            ]
        }"#;

        std::fs::write(&json_path, test_json).unwrap();
        let stats = db.import_memories_from_json(&json_path).unwrap();
        let _ = std::fs::remove_file(&json_path);

        assert_eq!(stats.total_read, 3);
        assert_eq!(stats.inserted, 1);
        assert_eq!(stats.skipped, 1);
        assert_eq!(stats.rejected, 1);

        let all = db.list_memories().unwrap();
        assert_eq!(all.len(), 2);
        // Ensure existing memory was preserved and not overwritten
        let rust_mem = all.iter().find(|m| m.keywords == vec!["rust"]).unwrap();
        assert_eq!(rust_mem.response, "Rust language original response");
    }
}
